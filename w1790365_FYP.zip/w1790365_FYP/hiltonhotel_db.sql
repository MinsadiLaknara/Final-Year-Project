-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2023 at 10:18 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hiltonhotel_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `admin_id` int(11) NOT NULL,
  `admin_first_name` varchar(20) NOT NULL,
  `admin_last_name` varchar(20) NOT NULL,
  `admin_email` varchar(30) NOT NULL,
  `admin_password` text NOT NULL,
  `admin_added_on` datetime NOT NULL,
  `admin_verification_code` text NOT NULL,
  `email_verify` enum('No','Yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`admin_id`, `admin_first_name`, `admin_last_name`, `admin_email`, `admin_password`, `admin_added_on`, `admin_verification_code`, `email_verify`) VALUES
(1, 'Min', 'Laknara', 'minsi@gmail.com', '6d3bb4865e3fcb97ad0cc6a4a89bdb06', '2023-04-24 06:39:52', '42fe1e89861b3f5a1066696b8621f515', 'Yes'),
(13, 'sara', 'lana', 'lanig52602@syinxun.com', '6d3bb4865e3fcb97ad0cc6a4a89bdb06', '2023-05-02 00:40:44', '8ffaf7419948d3a02006495baaf627cc', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `complain_table`
--

CREATE TABLE `complain_table` (
  `complain_id` int(11) NOT NULL,
  `issue_type_id` int(11) NOT NULL,
  `complain` text NOT NULL,
  `hotel_name` varchar(30) NOT NULL,
  `hotel_location` varchar(30) NOT NULL,
  `complainer_first_name` varchar(30) NOT NULL,
  `complainer_last_name` varchar(30) NOT NULL,
  `complainer_email` varchar(30) NOT NULL,
  `complain_status` enum('Solved','Pending') NOT NULL,
  `complain_added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complain_table`
--

INSERT INTO `complain_table` (`complain_id`, `issue_type_id`, `complain`, `hotel_name`, `hotel_location`, `complainer_first_name`, `complainer_last_name`, `complainer_email`, `complain_status`, `complain_added_on`) VALUES
(3, 2, 'The alarm was not working properly', 'Hampton by Hilton', 'London', 'Amiru', 'Manthrige', 'amiru@gmail.com', 'Pending', '2023-05-02 00:25:20'),
(4, 1, 'the billing was not balance', 'Hilton Garden Inn', 'London', 'Sisira', 'Manthrige', 'sisira@gmail.com', 'Pending', '2023-05-02 00:35:16'),
(6, 4, 'food was not good', 'The Waldorf Hilton', 'Blackpool', 'Minsadi', 'Manthrige', 'ml@gmail.com', 'Pending', '2023-05-02 09:25:03'),
(7, 6, 'The security alarm was broken', 'Conrad by Hilton', 'Doncaster', 'nethmi', 'umesha', 'nethmi@gmail.com', 'Pending', '2023-05-02 13:42:58');

-- --------------------------------------------------------

--
-- Table structure for table `issue_type`
--

CREATE TABLE `issue_type` (
  `issue_type_id` int(11) NOT NULL,
  `issue_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issue_type`
--

INSERT INTO `issue_type` (`issue_type_id`, `issue_type`) VALUES
(1, 'Accounts Issues'),
(2, 'Facility Issues'),
(3, 'Housekeeping Issues'),
(4, 'Kitchen Issues'),
(5, 'Management Issues'),
(6, 'Security Issues');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `complain_table`
--
ALTER TABLE `complain_table`
  ADD PRIMARY KEY (`complain_id`),
  ADD KEY `issue_type_id` (`issue_type_id`);

--
-- Indexes for table `issue_type`
--
ALTER TABLE `issue_type`
  ADD PRIMARY KEY (`issue_type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `complain_table`
--
ALTER TABLE `complain_table`
  MODIFY `complain_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `issue_type`
--
ALTER TABLE `issue_type`
  MODIFY `issue_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complain_table`
--
ALTER TABLE `complain_table`
  ADD CONSTRAINT `complain_table_ibfk_3` FOREIGN KEY (`issue_type_id`) REFERENCES `issue_type` (`issue_type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
