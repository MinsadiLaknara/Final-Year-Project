<?php

include('config.php');

$object = new Config;

include('header.php');

?>

      <div class="untree_co--site-main">
        

        <div class="untree_co--site-section float-left pb-0 featured-rooms">

          <div class="container pt-0 pb-5">
            <div class="row justify-content-center text-center">  
              <div class="col-lg-6 section-heading" data-aos="fade-up">
                <h3 class="text-center">About Us</h3>
              </div>
            </div>
          </div>

          <div class="container-fluid pt-5">
            <div class="suite-wrap overlap-image-1">

              <div class="suite">
                <div class="image-stack">
                  <div class="image-stack-item image-stack-item-top" data-jarallax-element="-50">
                    <div class="overlay"></div>
                    <img src="images/about_1.jpg" alt="Image" class="img-fluid pic1">
                  </div>
                  <div class="image-stack-item image-stack-item-bottom">
                    <div class="overlay"></div>
                    <img src="images/room_1_b.jpg" alt="Image" class="img-fluid pic2">
                  </div>
                </div>
              </div> <!-- .suite -->

              <div class="suite-contents" data-jarallax-element="50">
                <div class="suite-excerpt">
                  <p>Our hotel complaint review system is a platform dedicated to providing guests with a voice to share their experiences and feedback on their hotel stays. We believe that every guest deserves to have a memorable and enjoyable stay, and that their feedback is essential to ensuring that hotels provide exceptional service. Our system is designed to collect, store, and display reviews from guests in a transparent and reliable manner. We aim to provide a platform where guests can share their experiences and opinions without fear of censorship or bias. Our team is committed to maintaining the integrity of our system and ensuring that all reviews are treated with respect and professionalism. We strive to empower guests to make informed decisions about where to stay, and to help hotels improve the quality of service they provide. Our ultimate goal is to enhance the travel experience for all by fostering a culture of transparency and accountability in the hospitality industry.</p>
                </div>
              </div>
            </div>

            <div class="suite-wrap overlap-image-2">

              <div class="suite">
                <div class="image-stack">
                  <div class="image-stack-item image-stack-item-top">
                    <div class="overlay"></div>
                    <img src="images/room_2_a.jpg" alt="Image" class="img-fluid pic1">
                  </div>
                  <div class="image-stack-item image-stack-item-bottom" data-jarallax-element="-50">
                    <div class="overlay"></div>
                    <img src="images/about_3.jpg" alt="Image" class="img-fluid pic2">
                  </div>
                </div>
              </div>

              <div class="suite-contents" data-jarallax-element="50">
                <h2 class="suite-title">Vission</h2>
                <div class="suite-excerpt pr-5">
                  <p>Our vision for the hotel complaint review system is to become the leading platform for hotel guests to share their experiences and feedback. We aspire to create a system that is trusted, reliable, and widely recognized as a valuable tool for improving the quality of service provided by hotels. We envision a future where every guest feels empowered to share their honest feedback, and every hotel is committed to providing exceptional service. Through our platform, we aim to foster a culture of transparency and accountability in the hospitality industry and create a better travel experience for everyone. We strive to be the go-to source for reliable and insightful hotel reviews and to make a positive impact on the industry as a whole.</p>
                </div>
              </div>

            </div>
            <div class="suite-wrap overlap-image-1">

              <div class="suite">
                <div class="image-stack">
                  <div class="image-stack-item image-stack-item-top" data-jarallax-element="-50">
                    <div class="overlay"></div>
                    <img src="images/about_4.jpg" alt="Image" class="img-fluid pic1">
                  </div>
                  <div class="image-stack-item image-stack-item-bottom">
                    <div class="overlay"></div>
                    <img src="images/room_1_b.jpg" alt="Image" class="img-fluid pic2">
                  </div>
                </div>
              </div> <!-- .suite -->

              <div class="suite-contents" data-jarallax-element="50">
                <h2 class="suite-title">Mission</h2>
                <div class="suite-excerpt">
                  <p>At our hotel complaint review system, our mission is to provide a platform where guests can share their experiences and feedback on their stay at a hotel. We believe that honest and constructive feedback is essential for the continuous improvement of hotels and the overall guest experience. Our goal is to create a transparent and reliable system that benefits both guests and hoteliers. We aim to provide hotel managers with valuable insights into their customers' needs, expectations, and areas for improvement, while also empowering guests to make informed decisions about where to stay. Ultimately, we strive to enhance the quality of service provided by hotels and create a better travel experience for all.</p>
                </div>
              </div>
            </div>
          </div>
        </div>




      </div>

<?php
include('footer.php');
?>