      <footer class="untree_co--site-footer">

        <div class="container">
          <div class="row">
            <div class="col-md-4 pr-md-5">
              <h3>About Us</h3>
              <p>A hotel is an establishment that provides paid lodging on a short-term basis. Facilities provided may range from a modest-quality.</p>
              <p><a href="#" class="readmore">Read more</a></p>
            </div>
            <div class="col-md-8 ml-auto">
              <div class="row">
                <div class="col-md-3">
                  <h3>Navigation</h3>
                  <ul class="list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="AboutUs.php">About Us</a></li>
                    <li><a href="Complain.php">Contact</a></li>
					<li><a href="login_form.php">Sign In</a></li>
                  </ul>
                </div>
                <div class="col-md-9 ml-auto">
                  <div class="row mb-3">
                    <div class="col-md-6">
                      <h3>Address</h3>
                      <address>University of Westminster<br> London, United Kingdom</address>
                    </div>
                    <div class="col-md-6">
                      <h3>Telephone</h3>
                      <p>
                        <a href="#">+44 5678 910</a> <br>
                        <a href="#">+44 5678 910</a>
                      </p>
                    </div>
                  </div>

                  <h3 class="mb-0">Join our newsletter</h3>
                  <p>Be the first to know our latest updates and news!</p>
                  <form action="#" method="" class="form-subscribe">
                    <div class="form-group d-flex">
                      <input type="email" class="form-control mr-2" placeholder="Enter your email">
                      <input type="submit" value="Subscribe" class="btn btn-black px-4 text-white">
                    </div>
                  </form>
                </div>
                
              </div>
            </div>
          </div>
          <div class="row mt-5 pt-5 align-items-center">
            <div class="col-md-6 text-md-left">
              <!-- Link back to Untree.co can't be removed. Template is licensed under CC BY 3.0. If you purchased a license you can remove this. -->
              <p>
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <a href="index.html">Reviewist.co</a>. All Rights Reserved. Design by <a href="https://untree.co/" target="_blank" class="text-primary">Minsadi Laknara</a>
              </p>
            <!-- Link back to Untree.co can't be removed. Template is licensed under CC BY 3.0. If you purchased a license you can remove this. -->
            </div>
            <div class="col-md-6 text-md-right">
              <ul class="icons-top icons-dark">
              <li>
                <a href="https://www.facebook.com/HiltonHotels/"><span class="icon-facebook"></span></a>
              </li>
              <li>
                <a href="https://twitter.com/HiltonHotels?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><span class="icon-twitter"></span></a>
              </li>
              <li>
                <a href="https://www.instagram.com/hiltonhotels/?hl=en"><span class="icon-instagram"></span></a>
              </li>
            </ul>

            </div>
          </div>
        </div>
        
      </footer>
    </div>

    <!-- Search -->
    <div class="search-wrap">
      <a href="#" class="close-search js-search-toggle">
        <span>Close</span>
      </a>
      <div class="container">
        <div class="row justify-content-center align-items-center text-center">
          <div class="col-md-12">
            <form action="#">
              <input type="search" name="s" id="s" placeholder="Type a keyword and hit enter..."  autocomplete="false">
            </form>    
          </div>
        </div>

      </div>
    </div>

    <script src="js/vendor/jquery-3.3.1.min.js"></script>
    <script src="js/vendor/popper.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>

    <script src="js/vendor/owl.carousel.min.js"></script>
    
    <script src="js/vendor/jarallax.min.js"></script>
    <script src="js/vendor/jarallax-element.min.js"></script>
    <script src="js/vendor/ofi.min.js"></script>

    <script src="js/vendor/aos.js"></script>

    <script src="js/vendor/jquery.lettering.js"></script>
    <script src="js/vendor/jquery.sticky.js"></script>

    <script src="js/vendor/jquery.fancybox.min.js"></script>

    <script src="js/vendor/TweenMax.min.js"></script>
    <script src="js/vendor/ScrollMagic.min.js"></script>
    <script src="js/vendor/scrollmagic.animation.gsap.min.js"></script>
    <script src="js/vendor/debug.addIndicators.min.js"></script>
	<script src="/js/jquery-3.2.1.min.js"></script>


    <script src="js/main.js"></script>
  </body>
</html>