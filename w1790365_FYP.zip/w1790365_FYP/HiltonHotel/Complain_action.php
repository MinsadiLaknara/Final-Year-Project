<?php

include('config.php');

$object = new Config;

if(isset($_POST["action"]))
{
	if($_POST["action"] == 'Add')
	{

		$error = '';

		$success = '';

		$object->query = "
		SELECT issue_type_id FROM issue_type 
		WHERE issue_type = '".$_POST["issue_type"]."'
		";

		$result = $object->get_result();

		$data = array();

		foreach($result as $row)
		{
			$issue_type_id 				= $row['issue_type_id'];
		}

			if($error == '')
			{
			$complain					= $object->clean_input($_POST["complain"]);
			$hotel_name					= $object->clean_input($_POST["hotel_name"]);
			$hotel_location				= $object->clean_input($_POST["hotel_location"]);	
			$complainer_first_name		= $object->clean_input($_POST["complainer_first_name"]);
			$complainer_last_name		= $object->clean_input($_POST["complainer_last_name"]);
			$complainer_email			= $object->clean_input($_POST["complainer_email"]);
			
			$data = array(
				':issue_type_id'				=>	$issue_type_id,
				':complain'						=>	$complain,
				':hotel_name'					=>	$hotel_name,
				':hotel_location'				=>	$hotel_location,
				':complainer_first_name'		=>	$complainer_first_name,
				':complainer_last_name'			=>	$complainer_last_name,
				':complainer_email'				=>	$complainer_email,
				':complain_status'				=>	'Pending',
				':complain_added_on'			=>	$object->now
			);

			$object->query = "
			INSERT INTO complain_table 
			(issue_type_id, complain, hotel_name, hotel_location, complainer_first_name, complainer_last_name, complainer_email, complain_status, complain_added_on) 
			VALUES (:issue_type_id, :complain, :hotel_name, :hotel_location, :complainer_first_name, :complainer_last_name, :complainer_email, :complain_status, :complain_added_on)
			";

			$object->execute($data);

				header("Location:Complain.php?nodetails=Complain Sent!.");

			}else{
				header("Location:Complain.php?nodetails=Error sent!.");
			}
		

	}

}

?>