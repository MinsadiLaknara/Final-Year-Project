<?php

include('../../config.php');

$object = new Config;

if(isset($_POST["action"]))
{

	if($_POST["action"] == 'admin_profile')
	{

		$error = '';

		$success = '';
		
		$data = array();


			if($error == '')
			{
			$admin_first_name		= $object->clean_input($_POST["admin_first_name"]);
			$admin_last_name		= $object->clean_input($_POST["admin_last_name"]);	
			$admin_email			= $object->clean_input($_POST["admin_email"]);
			$admin_password			= $object->clean_input($_POST["admin_password"]);

			$data = array(
				':admin_first_name'			=>	$admin_first_name,
				':admin_last_name'			=>	$admin_last_name,
				':admin_email'				=>	$admin_email,
				':admin_password'			=>	md5($admin_password)
			);

			$object->query = "
			UPDATE admin_table  
			SET admin_first_name = :admin_first_name, 
			admin_last_name = :admin_last_name, 
			admin_email = :admin_email, 
			admin_password = :admin_password 
			WHERE admin_id = '".$_SESSION["id"]."'
			";

			$object->execute($data);

			header("Location:profile.php?nodetails=Profile Updated!.");

			}else{

				header("Location:profile.php?nodetails=Error!.");

			}


	}
}
?>