<?php

//Pet_action.php

include('../../Config.php');

$object = new Config;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
					
require '../PHPMailer-master/src/PHPMailer.php';
require '../PHPMailer-master/src/SMTP.php';
require '../PHPMailer-master/src/Exception.php';

if(isset($_POST["action"]))
{
	if($_POST["action"] == 'fetch')
	{
		$order_column = array('admin_id', 'admin_first_name', 'admin_last_name', 'admin_email');		

		$output = array();

		$main_query = "
		SELECT * FROM admin_table WHERE admin_id != 1
		";		

		$search_query = '';

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= 'AND admin_id LIKE "%'.$_POST["search"]["value"].'%" ';
		}

		if(isset($_POST["order"]))
		{
			$order_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_query = 'ORDER BY admin_id DESC ';
		}

		$limit_query = '';

		if($_POST["length"] != -1)
		{
			$limit_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$object->query = $main_query . $search_query . $order_query;

		$object->execute();

		$filtered_rows = $object->row_count();

		$object->query .= $limit_query;

		$result = $object->get_result();

		$object->query = $main_query;

		$object->execute();

		$total_rows = $object->row_count();

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();
			$sub_array[] = $row["admin_id"];
			$sub_array[] = $row["admin_first_name"] . ' ' . $row["admin_last_name"];
			$sub_array[] = $row["admin_email"];
			
			$sub_array[] = '
			<div align="center">
			<button type="button" name="view_button" class="btn btn-info btn-circle btn-sm view_button" data-id="'.$row["admin_id"].'"><i class="fas fa-eye"></i></button>
			<button type="button" name="delete_button" class="btn btn-danger btn-circle btn-sm delete_button" data-id="'.$row["admin_id"].'"><i class="fas fa-times"></i></button>
			</div>
			';
			$data[] = $sub_array;
		}

		$output = array(
			"draw"    			=> 	intval($_POST["draw"]),
			"recordsTotal"  	=>  $total_rows,
			"recordsFiltered" 	=> 	$filtered_rows,
			"data"    			=> 	$data
		);
			
		echo json_encode($output);

	}

	if($_POST["action"] == 'Add')
	{

		$error = '';

		$success = '';
		
		$data = array(
			':admin_email'	=>	$_POST["admin_email"]
		);

		$object->query = "
		SELECT * FROM admin_table 
		WHERE admin_email = :admin_email
		";
		
		$object->execute($data);

		if($object->row_count() > 0)
		{
			$error = '<div class="alert alert-danger">Email Address Already Exists</div>';
		}
		else
		{

			if($error == '')
			{
				$admin_verification_code = '8ffaf7419948d3a02006495baaf627cc';
				$data = array(
					':admin_first_name'			=>	$object->clean_input($_POST["admin_first_name"]),
					':admin_last_name'			=>	$object->clean_input($_POST["admin_last_name"]),
					':admin_email'				=>	$object->clean_input($_POST["admin_email"]),
					':admin_password'			=>	md5($object->clean_input($_POST["admin_password"])),
					':admin_added_on'			=>	$object->now,
					':admin_verification_code'	=>	$admin_verification_code,
					':email_verify'				=>	'No'
				);

				$object->query = "
				INSERT INTO admin_table 
				(admin_first_name, admin_last_name, admin_email, admin_password, admin_added_on, admin_verification_code, email_verify) 
				VALUES (:admin_first_name, :admin_last_name, :admin_email, :admin_password, :admin_added_on, :admin_verification_code, :email_verify)
				";

				$object->execute($data);

				$success = '<div class="alert alert-success">Admin Added</div>';
				
				$mail = new PHPMailer;
				$mail->IsSMTP();
				$mail->Host = "smtp.gmail.com"; 
				$mail->Port = '587';
				$mail->SMTPAuth = true;
				$mail->Username = 'SalvationJewellers';
				$mail->Password = 'uyizoajaamkpaglj';
				$mail->SMTPSecure = 'tsl';
				$mail->isHTML(true);  
				$mail->From = 'SalvationJewellers@gmail.com';
				$mail->FromName = 'Reviewist';
				$mail->AddAddress($_POST["admin_email"]);
				$mail->Subject = 'Verification code for Your Email Address';

				$message_body = '
				<p>To verify your email address, Please click on this <a href="'.$object->base_url.'verify.php?code='.$admin_verification_code.'"><b>link</b></a>.</p>
				<p>Sincerely,</p>
				<p>Hilton Hotel</p>
				';
				$mail->Body = $message_body;

				if($mail->Send())
				{
					$success = '<div class="alert alert-success">Please Verify Entered Email address</div>';
				}
				else
				{
					$error = '<div class="alert alert-danger">' . $mail->ErrorInfo . '</div>';
				}
			}

		}
		$output = array(
			'error'		=>	$error,
			'success'	=>	$success
		);

		echo json_encode($output);

	}

	if($_POST["action"] == 'fetch_single')
	{
		$object->query = "
		SELECT * FROM admin_table 
		WHERE admin_id = '".$_POST["admin_id"]."'
		";

		$result = $object->get_result();

		$data = array();

		foreach($result as $row)
		{
			$data['admin_id'] = $row['admin_id'];
			$data['admin_first_name'] = $row['admin_first_name'];
			$data['admin_last_name'] = $row['admin_last_name'];
			$data['admin_email'] = $row['admin_email'];
			$data['admin_added_on'] = $row['admin_added_on'];
			$data['email_verify'] = $row['email_verify'];
		}

		echo json_encode($data);
	}


	if($_POST["action"] == 'delete')
	{
		$object->query = "
		DELETE FROM admin_table 
		WHERE admin_id = '".$_POST["id"]."'
		";

		$object->execute();

		echo '<div class="alert alert-success">Admin Record Deleted</div>';
	}
}

?>