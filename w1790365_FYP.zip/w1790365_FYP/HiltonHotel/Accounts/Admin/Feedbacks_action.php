<?php

//doctor_action.php

include('../../Appointment.php');

$object = new Appointment;

if(isset($_POST["action"]))
{
	if($_POST["action"] == 'fetch')
	{
		$order_column = array('feedback_id','name','email','feedback');

		$output = array();

		$main_query = "
		SELECT * FROM feedback_table ";

		$search_query = '';

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= 'WHERE feedback_id LIKE "%'.$_POST["search"]["value"].'%" ';
			$search_query .= 'OR email LIKE "%'.$_POST["search"]["value"].'%" ';
		}

		if(isset($_POST["order"]))
		{
			$order_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_query = 'ORDER BY feedback_id DESC ';
		}

		$limit_query = '';

		if($_POST["length"] != -1)
		{
			$limit_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$object->query = $main_query . $search_query . $order_query;

		$object->execute();

		$filtered_rows = $object->row_count();

		$object->query .= $limit_query;

		$result = $object->get_result();

		$object->query = $main_query;

		$object->execute();

		$total_rows = $object->row_count();

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();
			$sub_array[] = $row["feedback_id"];
			$sub_array[] = $row["name"];
			$sub_array[] = $row["email"];
			$sub_array[] = $row["feedback"];

			$sub_array[] = '
			<div align="center">
			<button type="button" name="reply_button" class="btn btn-info btn-circle btn-sm reply_button" data-id="'.$row["feedback_id"].'"><i class="fas fa-reply"></i></button>
			<button type="button" name="delete_button" class="btn btn-danger btn-circle btn-sm delete_button" data-id="'.$row["feedback_id"].'"><i class="fas fa-times"></i></button>
			</div>
			';
			$data[] = $sub_array;
		}

		$output = array(
			"draw"    			=> 	intval($_POST["draw"]),
			"recordsTotal"  	=>  $total_rows,
			"recordsFiltered" 	=> 	$filtered_rows,
			"data"    			=> 	$data
		);
			
		echo json_encode($output);

	}

	if($_POST["action"] == 'reply'){

	 try{

	$mail = new PHPMailer(true);

		$mail->SMTPDebug=0;
		$mail->isSMTP();                      
		$email->SMTPAuth = true;                                         
		$mail->Host       = 'smtp.gmail.com';                    
		$mail->SMTPAuth   = true;                                   
		$mail->Username   = 'wearepetzone@gmail.com';
		$mail->Password   ='Rellik2Dema';



		$mail->SMTPSecure = 'tls';
		$mail->Port       = 587;  
		$mail->Mailer ='smtp';

		//--------------- get values
		$to = $_POST['txtTo'];
		$subject = $_POST['txtSubject'];
		$msg = $_POST['txtMessage'];

		//Recipients
		$mail->setFrom('wearepetzone@gmail.com');
		$mail->addAddress($to);     
		// Content
		$mail->isHTML(true);                                  
		$mail->Subject = $subject;
		$mail->Body    = $msg;

		$mail->send();
		$message='Message has been sent';
		header("Location:AdminFeedbackReply.php?nodetails=$message");

	 }catch(Exception $ex){
		$message= "Error : " . $mail->ErrorInfo;
	 }

	}	
	
	if($_POST["action"] == 'fetch_single')
	{
		$object->query = "
		SELECT * FROM feedback_table 
		WHERE feedback_id = '".$_POST["feedback_id"]."'
		";

		$result = $object->get_result();

		$data = array();

		foreach($result as $row)
		{
			$data['feedback_id'] = $row['feedback_id'];
			$data['name'] = $row['name'];
			$data['email'] = $row['email'];
			$data['feedback'] = $row['feedback'];

		}

		echo json_encode($data);
	}

	if($_POST["action"] == 'delete')
	{
		$object->query = "
		DELETE FROM feedback_table 
		WHERE feedback_id = '".$_POST["id"]."'
		";

		$object->execute();

		echo '<div class="alert alert-success">Feedback Record Deleted</div>';
	}
}

?>