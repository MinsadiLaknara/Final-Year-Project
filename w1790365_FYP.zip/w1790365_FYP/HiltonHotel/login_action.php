<?php

//login_action.php

include('config.php');

$object = new Config;

if(isset($_POST["user_email"]))
{

	$error = '';
	$url = '';
	$data = array(
		':user_email'	=>	$_POST["user_email"]
		
	);

	$object->query = "
		SELECT * FROM admin_table 
		WHERE admin_email = :user_email
	";
	
	$user_password = $_POST['user_password'];
	
	$object->execute($data);
	$result = $object->statement_result();

	$total_row = $object->row_count();

	if($total_row == 0)
	{
		$error = '<div class="alert alert-danger">Wrong Email Address</div>';
		
	}else{

		foreach($result as $row)
		{
			if($row["email_verify"] == 'Yes')
			{

				if(md5($user_password) == $row["admin_password"])
				{
					$_SESSION['id'] = $row['admin_id'];
					$_SESSION['type'] = 'Admin';
					$url = $object->base_url . 'Accounts/Admin/dashboard.php';
				}
				else
				{
					$error = '<div class="alert alert-danger">Wrong Password</div>';
				}
			}
			else
			{
				$error = '<div class="alert alert-danger">Please verify your email address</div>';
			}
				
		}
	}

	$output = array(
		'error'		=>	$error,
		'url'		=>	$url
	);

	echo json_encode($output);
}

?>