
<?php

include('config.php');

$object = new Config;

include('header.php');

?>

      <main class="untree_co--site-main">
      
        
        <div class="untree_co--site-section">
          <div class="container">
            
              <div class="row">
                <div class="col-12" data-aos="fade-up">
                  <h2 class="display-4 mb-5">Enter Your Complain</h2>
                </div>
                <div class="col-md-6 mb-5 mb-md-0" data-aos="fade-up" data-aos-delay="100">
                  
                  <form action="Complain_action.php" method="post" id="complain_form" >
					<span id="form_message"></span>  
                    <div class="form-group">
                      <label>First Name *</label>
                      <input type="text" class="form-control" id="complainer_first_name" name="complainer_first_name" class="form-control" required />
                    </div>
					<div class="form-group">
                      <label>Last Name *</label>
                      <input type="text" class="form-control" id="complainer_last_name" name="complainer_last_name" class="form-control" required />
                    </div>
                    <div class="form-group">
                      <label>Your Email *</label>
                      <input type="email" class="form-control" id="complainer_email" name="complainer_email" class="form-control" required />
                    </div>
                    <div class="form-group">
                      <label>Hotel Name</label><br>
                      <select id="hotel_name" class="form-control" name="hotel_name">
						<option selected="" disabled="">Select a Hotel Branch</option>
                        <option value="Hampton by Hilton">Hampton by Hilton</option>
                        <option value="DoubleTree by Hilton">DoubleTree by Hilton</option>
                        <option value="Hilton Garden Inn">Hilton Garden Inn</option>
                        <option value="Conrad by Hilton">Conrad by Hilton </option>
                        <option value="The Waldorf Hilton">The Waldorf Hilton</option>
                        <option value="Curio Collection by Hilton">Curio Collection by Hilton</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Hotel Location</label>
                      <select id="hotel_location" class="form-control" name="hotel_location">
						<option selected="" disabled="">Select a Branch Location</option>
                        <option value="Blackburn">Blackburn</option>
                        <option value="Blackpool">Blackpool</option>
						<option value="Chester">Chester</option>
                        <option value="Conwy">Conwy</option>
						<option value="Doncaster">Doncaster</option> 
                        <option value="Harrogate">Harrogate</option>
                        <option value="Hampton">Hampton</option>
                        <option value="Liverpool">Liverpool</option>
                        <option value="Leeds">Leeds</option>
                        <option value="London">London</option>
						<option value="Manchester">Manchester</option>
                        <option value="Stoke on Tred">Stoke on Tred</option>
                        <option value="Sheffield">Sheffield</option>
                        <option value="York">York</option>
                          
                      </select>
                    </div>
					<div class="form-group">
		                <label>Issue Types</label>
		                <select class="form-control" id="issue_type" name="issue_type">
		                	<option selected="" disabled="">Select an Issue Type</option>
							<option value="Accounts Issues">Accounts Issues</option>
							<option value="Facility Issues">Facility Issues</option>
							<option value="Housekeeping Issues">Housekeeping Issues</option>
							<option value="Kitchen Issues">Kitchen Issues</option>
							<option value="Management Issues">Management Issues</option> 
							<option value="Security Issues">Security Issues</option>
		                </select>
		            </div>
                    <div class="form-group">
                      <label>Message *</label>
                      <textarea name="complain" class="form-control" id="complain" cols="30" rows="10"></textarea>
                    </div>
                    <div class="form-group">
					<input type="hidden" name="hidden_id" id="hidden_id" />
          			<input type="hidden" name="action" id="action" value="Add" />
          			<input type="submit" name="submit" id="submit_button" class="btn btn-success" value="Add" />
                    </div>
                  </form>
                </div>
              </div>
            
          </div>
        </div>

      </main>
<script>
	
$(document).ready(function(){	
	
	$('#complain_form').on('submit', function(event){

		event.preventDefault();

			$.ajax({
				url:"Complain_action.php",
				method:"POST",
				data:new FormData(this),
				dataType:'json',
				beforeSend:function(){
					$('#submit_button').attr('disabled', 'disabled');
					$('#submit_button').val('wait...');
				},
				success:function(data)
				{
					$('#submit_button').attr('disabled', false);
					$('#complain_form')[0].reset();
					if(data.error !== '')
					{
						$('#message').html(data.error);
					}
					if(data.success != '')
					{
						$('#message').html(data.success);

					}
				}
			});

	});

});	

</script>


<?php

include ('footer.php');

?>