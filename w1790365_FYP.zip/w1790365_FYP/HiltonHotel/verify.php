<?php

//verify.php

include('Config.php');

$object = new Config;

if(isset($_GET["code"]))
{
	$object->query = "
	UPDATE admin_table 
	SET email_verify = 'Yes' 
	WHERE admin_verification_code = '".$_GET["code"]."'
	";

	$object->execute();

	$_SESSION['success_message'] = '<div class="alert alert-success">Email has been verified</div>';

	header("location:Accounts/Admin/Admin.php?nodetails=Admin Added Successful!.");

}


?>